# Mango Fruit > 2026-01-09 5:24pm
https://universe.roboflow.com/test-mango/mango-fruit-gcres

Provided by a Roboflow user
License: CC BY 4.0

